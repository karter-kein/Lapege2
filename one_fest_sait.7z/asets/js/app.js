const headerTop = document.querySelector('.headerTop')

window.addEventListener('scroll', function() {
	let scrollP = window.scrollY

	

	if (scrollP < 481) {
		headerTop.classList.remove('green')
		headerTop.classList.remove('blue')
		headerTop.classList.remove('white')
		headerTop.classList.remove('ffdd9a')
		headerTop.classList.remove('red')
	}

	if (scrollP > 483) {
		headerTop.classList.add('green')
		headerTop.classList.remove('blue')
		headerTop.classList.remove('white')
		headerTop.classList.remove('ffdd9a')
		headerTop.classList.remove('red')
	}
	
	if (scrollP > 1241) {
		headerTop.classList.add('blue')
		headerTop.classList.remove('green')
		headerTop.classList.remove('white')
		headerTop.classList.remove('ffdd9a')
		headerTop.classList.remove('red')
	}

	if (scrollP > 2182) {
		headerTop.classList.add('white')
		headerTop.classList.remove('green')
		headerTop.classList.remove('blue')
		headerTop.classList.remove('ffdd9a')
		headerTop.classList.remove('red')
	}

	if (scrollP > 2850) {
		headerTop.classList.add('ffdd9a')
		headerTop.classList.remove('white')
		headerTop.classList.remove('green')
		headerTop.classList.remove('blue')
		headerTop.classList.remove('red')
	}

	if (scrollP > 4230) {
		headerTop.classList.add('red')
		headerTop.classList.remove('white')
		headerTop.classList.remove('green')
		headerTop.classList.remove('blue')
		headerTop.classList.remove('ffdd9a')
	}

})